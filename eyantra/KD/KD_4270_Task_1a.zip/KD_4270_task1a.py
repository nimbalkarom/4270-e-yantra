import cv2
import numpy as np
import argparse
import sys

def main():
    # 1. Setup Argparse to read the image name from the terminal
    parser = argparse.ArgumentParser(description="Khojo-Drone Task 1A Vision Pipeline")
    parser.add_argument('--image', required=True, help="Path to the arena image")
    args = parser.parse_args()

    # 2. Load the image
    image = cv2.imread(args.image)
    if image is None:
        print(f"Error: Could not load image at {args.image}")
        sys.exit(1)

    # 3. ArUco Detection Setup (For OpenCV 4.7+)
    dictionary = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_250)
    parameters =  cv2.aruco.DetectorParameters()
    detector = cv2.aruco.ArucoDetector(dictionary, parameters)

    # Detect the markers
    corners, ids, rejected = detector.detectMarkers(image)
    
    # DEBUG: Draw the markers on the original image so we can read their IDs
    cv2.aruco.drawDetectedMarkers(image, corners, ids)
    #cv2.imshow("Marker Check", image)
    #cv2.waitKey(0)

    if ids is None or len(ids) < 4:
        print("Error: Could not find all 4 markers!")
        sys.exit(1)

   # 4. Extracting the inner corners dynamically
    pt_TL = None # Top-Left (ID 80)
    pt_TR = None # Top-Right (ID 85)
    pt_BR = None # Bottom-Right (ID 90)
    pt_BL = None # Bottom-Left (ID 95)

    # Find the geographical center of the image
    height, width = image.shape[:2]
    center_x, center_y = width / 2, height / 2

    # Helper function to find the corner closest to the center
    def get_inner_corner(marker_corners):
        min_dist = float('inf')
        inner_corner = None
        for corner in marker_corners:
            # Calculate Euclidean distance to the image center
            dist = (corner[0] - center_x)**2 + (corner[1] - center_y)**2
            if dist < min_dist:
                min_dist = dist
                inner_corner = corner
        return inner_corner

    # Loop through the detected IDs and grab the closest corner
    for i, marker_id in enumerate(ids.flatten()):
        marker_corners = corners[i][0] 
        inner = get_inner_corner(marker_corners)
        
        if marker_id == 80:
            pt_TL = inner
        elif marker_id == 85:
            pt_TR = inner
        elif marker_id == 90:
            pt_BR = inner
        elif marker_id == 95:
            pt_BL = inner

    # 5. Define Source and Destination Arrays for the Transform
    src_points = np.float32([pt_TL, pt_TR, pt_BR, pt_BL])
    dst_points = np.float32([[0, 0], [900, 0], [900, 900], [0, 900]])

    matrix = cv2.getPerspectiveTransform(src_points, dst_points)
    warped_image = cv2.warpPerspective(image, matrix, (900, 900))
    
    # 5.5 Draw the Grid to verify mathematical accuracy
    for i in range(1, 12):
        coord = i * 75
        # Draw vertical line (x is constant, y goes from 0 to 900)
        cv2.line(warped_image, (coord, 0), (coord, 900), (0, 255, 0), 1)
        # Draw horizontal line (y is constant, x goes from 0 to 900)
        cv2.line(warped_image, (0, coord), (900, coord), (0, 255, 0), 1)
        
    # 6. Color Masking (Signal Extraction)
    hsv_image = cv2.cvtColor(warped_image, cv2.COLOR_BGR2HSV)

    # Define HSV range for Red (Critical Survivors)
    lower_red1 = np.array([0, 100, 100])
    upper_red1 = np.array([10, 255, 255])
    lower_red2 = np.array([160, 100, 100])
    upper_red2 = np.array([180, 255, 255])
    
    mask_red1 = cv2.inRange(hsv_image, lower_red1, upper_red1)
    mask_red2 = cv2.inRange(hsv_image, lower_red2, upper_red2)
    mask_red = cv2.bitwise_or(mask_red1, mask_red2)

    # Define HSV range for Yellow (Stable Survivors)
    lower_yellow = np.array([20, 100, 100])
    upper_yellow = np.array([35, 255, 255])
    mask_yellow = cv2.inRange(hsv_image, lower_yellow, upper_yellow)

    # DEBUG: Show the masks to verify color isolation
    #cv2.imshow("Red Mask", mask_red)
    #cv2.imshow("Yellow Mask", mask_yellow)
    
    # 7. Find Centroids and Map to Grid
    def process_survivors(mask, color_name, draw_color):
        locations = []
        # Find the shapes in the mask
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        for cnt in contours:
            # Filter out tiny noise specks
            if cv2.contourArea(cnt) > 100:
                # Calculate the center of mass (centroid)
                M = cv2.moments(cnt)
                if M["m00"] != 0:
                    cx = int(M["m10"] / M["m00"])
                    cy = int(M["m01"] / M["m00"])
                    
                    # Math: Divide by cell width (75) and round to find nearest intersection
                    col_num = round(cx / 75.0)
                    row_num = round(cy / 75.0)
                    
                    # Math: Convert column number to a letter (1 -> A, 2 -> B, etc.)
                    col_letter = chr(64 + col_num)
                    grid_label = f"{col_letter}{row_num}"
                    locations.append(grid_label)
                    
                    # DEBUG: Draw the contour, centroid, and label on the warped image
                    cv2.drawContours(warped_image, [cnt], -1, draw_color, 2)
                    cv2.circle(warped_image, (cx, cy), 5, (255, 255, 255), -1)
                    cv2.putText(warped_image, grid_label, (cx + 10, cy - 10), 
                                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        return locations

    # Run the function for both masks
    critical_survivors = process_survivors(mask_red, "Red", (0, 0, 255))
    stable_survivors = process_survivors(mask_yellow, "Yellow", (0, 255, 255))
    
    print(f"Critical Survivors: {critical_survivors}")
    print(f"Stable Survivors: {stable_survivors}")
    
    # 6. Display the result
    #cv2.imshow("Warped Arena", warped_image)
    #cv2.waitKey(0)
    
   # 8. Generate the required results file
    output_filename = args.image.rsplit('.', 1)[0] + '_results.txt'
    
    # FIX 1: Convert numpy integers to standard Python integers
    detected_ids_list = sorted([int(x) for x in ids.flatten()])
    
    # FIX 2: Use set() to remove duplicate coordinates, then sort them cleanly
    clean_critical = sorted(list(set(critical_survivors)))
    clean_stable = sorted(list(set(stable_survivors)))
    
    with open(output_filename, 'w') as f:
        # CRITICAL FIX: Only a single \n at the end of this line!
        f.write(f"Detected marker IDs: {detected_ids_list}\n")
        f.write(f"Critical Survivors: {', '.join(clean_critical)}\n")
        f.write(f"Stable Survivors: {', '.join(clean_stable)}\n")
        
    print(f"Success! Output written to {output_filename}")
    
    # Final Visual Check (Remember to remove this before actual submission!)
    #cv2.imshow("Final Annotated Arena", warped_image)
    #cv2.waitKey(0)

if __name__ == "__main__":
    main()
